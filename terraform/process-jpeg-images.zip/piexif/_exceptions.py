class InvalidImageDataError(ValueError):
    pass
